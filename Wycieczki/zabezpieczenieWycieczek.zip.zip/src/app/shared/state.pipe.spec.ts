import { StatePipe } from './state.pipe';

describe('StatePipe', () => {
  it('create an instance', () => {
    const pipe = new StatePipe();
    expect(pipe).toBeTruthy();
  });
});
