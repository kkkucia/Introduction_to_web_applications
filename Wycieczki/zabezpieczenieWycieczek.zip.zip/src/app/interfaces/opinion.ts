export interface IOpinion {
    login: string;
    name: string;
    opinion: string;
    date: string;
}
