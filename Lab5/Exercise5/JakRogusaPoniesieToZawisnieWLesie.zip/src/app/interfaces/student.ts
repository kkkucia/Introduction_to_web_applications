export class Student {
  "key": string;
  "name": string;
  "age": number;
}
