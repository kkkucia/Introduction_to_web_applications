import { Injectable } from '@angular/core';
import { AngularFireDatabaseModule} from '@angular/fire/compat/database';
import { Student } from '../interfaces/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {


  constructor(private db: AngularFireDatabaseModule) {

  }

  createStudent(student: Student): void {

  }

  updateStudent(key: string, value: any) {

  }

  deleteStudent(key: string) {

  }

  getStudentsList() {

  }

  deleteAll() {
  }

}
